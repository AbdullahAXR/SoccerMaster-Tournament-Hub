This readMe.txt file to provide information about any needed installation/library. any required application authentication or a key, should be provided here.

Node installation needed.